import boto3
import re

from html import escape
from html.parser import HTMLParser

class ParlerParser(HTMLParser):
    def __init__(self, data):
        self.result = {}
        self.feed(data)

    def handle_starttag(self, tag, attributes):
        pass

    def handle_endtag(self, tag):
        pass

    def handle_data(self, data):
        pass

    @staticmethod
    def __attr_str(attrs):
        return ' '.join('{}="{}"'.format(name, escape(value)) for (name, value) in attrs)
    





def handler(event, context): 
    #access to s3 data [parler stuff]
    #access to dynamodb table [how much done]

    table_name = event['table_name']
    input_name = event['input_bucket']
    output_name = event['output_bucket']

    input_bucket = boto3.resource('s3').Bucket(input_name)
    output_bucket = boto3.resource('s3').Bucket(output_name)
    table = boto3.resource('dynamodb').Table(table_name)

    for obj in input_bucket.objects():
        with open(obj.key, 'wb') as data:
            input_bucket.download_fileobj(obj.key, data)
            # table.put_item(Item=ParlerParser(data).result)
            output_bucket.upload_file(obj.key, obj.key)
        
        input_bucket.delete_objects(Delete={"Objects": [{"Key": obj.key}]})


    


    


    return some_value